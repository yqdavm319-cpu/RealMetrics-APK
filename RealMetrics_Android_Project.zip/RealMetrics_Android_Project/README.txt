RealMetrics Android project (V7)

This is an Android Studio project that wraps the RealMetrics V7 web app in a native Android WebView. It is project source, NOT a compiled APK.

Build the APK:
1. Install Android Studio on a computer.
2. Open this folder as an existing project.
3. Let Android Studio sync Gradle and install any requested Android SDK components (compile SDK 35).
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK is usually at app/build/outputs/apk/debug/app-debug.apk.
6. Transfer that APK to your Android phone and install it. You may need to allow installation from that file manager.

App id: com.mayank.realmetrics
Version: 7.0
Minimum Android: Android 6.0 (API 23)

Notes:
- Study app data is stored locally by the embedded web app.
- Reminder preferences do not send background notifications.
- This project requires Android Studio/Android SDK to compile; no APK is included in this ZIP.
